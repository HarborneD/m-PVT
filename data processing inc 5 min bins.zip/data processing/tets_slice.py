

list_samp = [1,2,3]

print(list_samp[-2:])